#include <stdio.h>

int main() {
    printf("Goodbye, World!\n");
    return 0;
}